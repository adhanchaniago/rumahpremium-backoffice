<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function site()
{
	return 'http://localhost/rumahpremium/';
}
?>