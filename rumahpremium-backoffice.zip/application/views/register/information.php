<div class="container-fluid" style="  background: radial-gradient(ellipse at bottom, #FFF 0%, blue 100%); overflow: hidden;">
	<!-- <div class="container-fluid" style="  background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%); overflow: hidden;"> -->
<div id='stars'></div>
<div id='stars2'></div>
<div id='stars3'></div>
	<div class="row">
		<div class="col-4 offset-4">
			<div class="card shadow my-4 position-relative" style="z-index: 1000; background: #FFF;">
				<div class="card-body">
					<div class="text-center">
	                    <img src="<?php echo base_url(); ?>assets/logo.png" width="60">
	                    <h5 class="mt-3 mb-2"><strong>Selangkah lagi untuk membuat toko online Anda</strong></h5>
	                    <h6 class="mb-4 text-muted">Izinkan kami mengetahui informasi berikut ini</h6>
	                </div>
	                <hr>
	                <div class="px-5 pt-2">
						<form>
							<div class="form-group fontsize-smaller">
								<label for="input-fullname">Nama Toko Anda</label>
								<input type="email" class="form-control" id="input-fullname" aria-describedby="emailHelp" name="user_fullname">
							</div>
							<div class="form-group fontsize-smaller">
								<label for="exampleInputPassword1">Toko/Tempat Tinggal Anda</label>
								<select class="form-control mb-2" id="input-email" name="user_email">
									<option>Pilih Kota</option>
								</select>
								<select class="form-control" id="input-email" name="user_email">
									<option>Pilih Kota</option>
								</select>
							</div>
							<div class="form-group fontsize-smaller">
								<label for="exampleInputPassword1">Nama Akun Instagram</label>
								<input type="text" class="form-control" id="input-email" placeholder="Akun Instagram" name="user_phone">
							</div>
							<button type="submit" class="btn btn-block btn-primary">Daftar</button>
						</form>
					</div>
					<hr>
					<div class="my-4 text-center">
						<small>Menemui kesulitan? <a href="<?php echo base_url(); ?>login">Kami siap membantu</a></small>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>