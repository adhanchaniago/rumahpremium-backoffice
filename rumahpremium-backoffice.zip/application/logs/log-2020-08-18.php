ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Js/popper.min.js.map
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Js/bootstrap.min.js.map
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Plugins/table
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Plugins/numeric
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_by C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_updated_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_by C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_updated_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_by C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_updated_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_by C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_updated_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_by C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_updated_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_by C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 26
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_created_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:31:12 --> Severity: Notice --> Undefined property: stdClass::$item_updated_date C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 27
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Js/bootstrap.min.js.map
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Js/popper.min.js.map
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Plugins/table
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Plugins/numeric
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:02 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:02 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:02 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:02 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:02 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:02 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:05 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:05 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:05 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:05 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:05 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:05 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:05 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:05 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:05 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\date_helper.php 11
ERROR - 2020-08-18 05:33:54 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:54 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:33:54 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:51 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:51 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:51 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:59 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:59 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:34:59 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:37:08 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:37:13 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:01 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:24 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\xampp\htdocs\rumahpremium-backoffice\application\helpers\base_helper.php 7
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:32 --> 404 Page Not Found: Assets/item
ERROR - 2020-08-18 05:39:41 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:39:41 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:39:42 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:39:54 --> 404 Page Not Found: Product/form
ERROR - 2020-08-18 05:39:55 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:40:13 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:40:13 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:40:13 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:40:15 --> 404 Page Not Found: Product/form
ERROR - 2020-08-18 05:40:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:46:16 --> 404 Page Not Found: Product/form
ERROR - 2020-08-18 05:46:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:04 --> 404 Page Not Found: Product/form
ERROR - 2020-08-18 05:47:20 --> 404 Page Not Found: Product/form
ERROR - 2020-08-18 05:47:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:47:23 --> Severity: error --> Exception: Call to undefined function store_detail() C:\xampp\htdocs\rumahpremium-backoffice\application\models\Model_category.php 75
ERROR - 2020-08-18 05:47:49 --> Severity: error --> Exception: Call to undefined function store_detail() C:\xampp\htdocs\rumahpremium-backoffice\application\models\Model_category.php 75
ERROR - 2020-08-18 05:47:55 --> Severity: error --> Exception: Call to undefined method Model_item::product_detail() C:\xampp\htdocs\rumahpremium-backoffice\application\controllers\Item.php 81
ERROR - 2020-08-18 05:48:16 --> Query error: Unknown column 'item_url' in 'where clause' - Invalid query: SELECT *
FROM `item`
WHERE `item_url` = 'villa-mutiara-gading-2-blok-pq'
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 25
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 41
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 63
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 69
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 76
ERROR - 2020-08-18 05:48:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 76
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 92
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 104
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 123
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 144
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 156
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 168
ERROR - 2020-08-18 05:48:34 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 180
ERROR - 2020-08-18 05:48:35 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:48:35 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:48:35 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 61
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 67
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 90
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 102
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 121
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 142
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 154
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 166
ERROR - 2020-08-18 05:49:01 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 178
ERROR - 2020-08-18 05:49:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 61
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 67
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 90
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 102
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 121
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 142
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 154
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 166
ERROR - 2020-08-18 05:49:16 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 178
ERROR - 2020-08-18 05:49:16 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:16 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:16 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 52
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 58
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 65
ERROR - 2020-08-18 05:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 65
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 81
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 93
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 112
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 133
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 145
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 157
ERROR - 2020-08-18 05:49:21 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 169
ERROR - 2020-08-18 05:49:21 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:21 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:21 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 61
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 67
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 90
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 102
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 121
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 142
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 154
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 166
ERROR - 2020-08-18 05:49:30 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 178
ERROR - 2020-08-18 05:49:31 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:31 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:31 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 61
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 67
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 90
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 102
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 121
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 142
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 154
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 166
ERROR - 2020-08-18 05:49:43 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 178
ERROR - 2020-08-18 05:49:43 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:43 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:43 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 61
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 67
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 90
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 102
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 121
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 142
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 154
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 166
ERROR - 2020-08-18 05:49:48 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 178
ERROR - 2020-08-18 05:49:48 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:48 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:48 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_title C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 60
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 66
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 73
ERROR - 2020-08-18 05:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 73
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 89
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 101
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 120
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 141
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 153
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 165
ERROR - 2020-08-18 05:49:53 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 177
ERROR - 2020-08-18 05:49:53 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:53 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:49:53 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined variable: item_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 60
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Trying to get property 'title_item' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 60
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_sku C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 66
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 73
ERROR - 2020-08-18 05:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 73
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 89
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 101
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 120
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 141
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 153
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 165
ERROR - 2020-08-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 177
ERROR - 2020-08-18 05:50:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:02 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined variable: item_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 60
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Trying to get property 'title_item' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 60
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_price_real C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_price_cost C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 87
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_discount C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 106
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_weight C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 127
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_length C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 139
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_width C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 151
ERROR - 2020-08-18 05:50:11 --> Severity: Notice --> Undefined property: stdClass::$product_height C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 163
ERROR - 2020-08-18 05:50:11 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:11 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:12 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_price_real' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 87
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_price_cost' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 87
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 106
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_discount' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 106
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 127
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_weight' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 127
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 139
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_length' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 139
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 151
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_width' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 151
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 163
ERROR - 2020-08-18 05:50:24 --> Severity: Notice --> Trying to get property 'product_height' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 163
ERROR - 2020-08-18 05:50:24 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:24 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:24 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 70
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_price_real' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 70
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 85
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_price_real' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 85
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 97
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_price_cost' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 97
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 116
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_discount' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 116
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 137
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_weight' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 137
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 149
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_length' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 149
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 161
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_width' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 161
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 173
ERROR - 2020-08-18 05:50:51 --> Severity: Notice --> Trying to get property 'product_height' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 173
ERROR - 2020-08-18 05:50:51 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:51 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:50:51 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 85
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_price_real' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 85
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 97
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_price_cost' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 97
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 116
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_discount' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 116
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 137
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_weight' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 137
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 149
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_length' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 149
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 161
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_width' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 161
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 173
ERROR - 2020-08-18 05:51:00 --> Severity: Notice --> Trying to get property 'product_height' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 173
ERROR - 2020-08-18 05:51:01 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:01 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:01 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:17 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 84
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Trying to get property 'product_weight' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 84
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 96
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Trying to get property 'product_length' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 96
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 108
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Trying to get property 'product_width' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 108
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 120
ERROR - 2020-08-18 05:51:18 --> Severity: Notice --> Trying to get property 'product_height' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 120
ERROR - 2020-08-18 05:51:18 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:18 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:18 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:26 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:26 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:26 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:26 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:46 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:46 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:46 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:46 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:46 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:46 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:46 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 23
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Trying to get property 'product_code' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 39
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 84
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Trying to get property 'product_weight' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 84
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 96
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Trying to get property 'product_length' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 96
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 108
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Trying to get property 'product_width' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 108
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Undefined variable: product_detail C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 120
ERROR - 2020-08-18 05:51:55 --> Severity: Notice --> Trying to get property 'product_height' of non-object C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 120
ERROR - 2020-08-18 05:51:56 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:56 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:51:56 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:11 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 77
ERROR - 2020-08-18 05:52:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 77
ERROR - 2020-08-18 05:52:11 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:11 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:11 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:31 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 77
ERROR - 2020-08-18 05:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 77
ERROR - 2020-08-18 05:52:31 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:31 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:31 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:52 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:52:53 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:53 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:53 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:58 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:52:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:52:58 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:58 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:52:58 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:07 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:53:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:22 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:53:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 75
ERROR - 2020-08-18 05:53:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:27 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:53:27 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:27 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:27 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:34 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:53:34 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:34 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:34 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:52 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:53:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 74
ERROR - 2020-08-18 05:53:52 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:52 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:52 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:53:59 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:53:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:00 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:00 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:00 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:07 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:07 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:07 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:07 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:17 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:32 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:33 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:33 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:33 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:45 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:54:45 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:45 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:54:45 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:17 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:17 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:21 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:41 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:41 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:41 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:41 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:57 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:55:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:55:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:56:28 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:56:28 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:56:28 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:56:28 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:56:57 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:56:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:56:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:56:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:56:57 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:09 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:09 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:09 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:09 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:14 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:14 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:14 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:14 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:26 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:33 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:33 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:33 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:33 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:34 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:35 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:35 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:35 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:39 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:57:39 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:39 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:57:39 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:08 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:08 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:09 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:25 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:26 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:32 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:32 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:32 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:32 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:34 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:34 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:34 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:34 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:36 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:58:36 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:36 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:58:36 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:59:24 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:59:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:59:24 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:59:24 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:59:24 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:59:28 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 05:59:28 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:59:28 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 05:59:28 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:22 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:00:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:22 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:30 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:00:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:00:30 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:30 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:30 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:43 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:00:43 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:43 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:00:43 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:01:01 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:01:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:01:01 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:01:01 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:01:01 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:02:07 --> Severity: Notice --> Undefined variable: category_list C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:02:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rumahpremium-backoffice\application\views\item\item-edit.php 78
ERROR - 2020-08-18 06:02:07 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:02:07 --> 404 Page Not Found: Img/favicon
ERROR - 2020-08-18 06:02:07 --> 404 Page Not Found: Img/favicon
