jQuery(document).ready(function() {
    jQuery("time.timeago").timeago();
});

$('[data-toggle="popover"]').popover();